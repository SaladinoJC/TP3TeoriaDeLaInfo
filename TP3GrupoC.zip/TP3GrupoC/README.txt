Para ejecutar el script de python hay que tener python instalado en la pc y desde terminal:
python Tp3.py -c o -d (comprimir, descomprimir) "nombre del archivo original" "nombre del archivo comprimido"

En el archivo comprimido se adjunta:
--El ejecutable Tp3.py
--Todos los samples:
	ejemplo_compresion.pdf
	ejemplopractica.txt
	ejemplopracticaextendido.txt	
	imagenblanca.raw
	imagencomun.raw
	martinfierro.txt
	productos.xml
	video.mp4
--Algunos de los samples comprimidos (no todos porque el .zip terminaba pesando mas de 10MB y no se podía subir al cmapus)
	ejemplo_compresion.bin
	ejemplopractica.bin
	ejemplopracticaextendido.bin
	martinfierro.bin
	productos.bin
	video.bin

